package com.example.quiz_hepatite_a

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
